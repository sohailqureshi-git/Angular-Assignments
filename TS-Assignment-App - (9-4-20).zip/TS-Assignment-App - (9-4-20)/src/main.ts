import { enableProdMode } from '@angular/core';
enableProdMode();
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { Factorial } from './assignment-files/factorial-number';
import { PrimeNumber } from './assignment-files/prime-number';
import { ArithmeticOperation } from './assignment-files/arithmetic-operators';
import { DigitalClock } from './assignment-files/digital-clock';
import { Student } from './assignment-files/arrow-function';
import { Discount } from './assignment-files/discount-calculation';
import { EvenSorted } from './assignment-files/even-sorted';
import { Employee } from './assignment-files/employee-details';

if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));

// Run TS files code

let num: number = 5
var getfactorial = new Factorial().calculateFactorial(num);
console.log('1) The factorial of '+ num +' is '+ getfactorial +'');

let primeNumbers: number = 100
var getPrimeNumbers = new PrimeNumber().getPrimeNumbers(primeNumbers);
console.log('2) The prime numbers between 1 to 100 is ('+ getPrimeNumbers +')');

let x: number = 15;
let y: number = 5;
var getResult = new ArithmeticOperation().doCalculations(x,y);
console.log('3) The add,sub,mul & div of '+ x +' & '+ y +' is ('+ getResult +')');

let objEmployee = new Employee('Sohail', 'Green', 2020, 45);
var result = objEmployee.getEmpDetails();
console.log('4) The employee details are ('+ result +')');

var getTime = new DigitalClock().showTime();
console.log('5) The digital clock time  is ('+ getTime +')');

let objStudent = new Student(1010612, 'Sohail');
var getDetails = objStudent.showDetails();
console.log('6) The enrollmentNo & name of student is ('+ getDetails +')');

let priceArr : number[] = [100,26,76,84];
var getDiscounts = new Discount().getDiscount(priceArr);
console.log('7) The 50% discount of prices '+ priceArr +' are ('+ getDiscounts +')');

let numArr : number[] = [87,43,2,98,56,33,21,34,97,43,24,76,58,10,7,32];
var getevenSorted = new EvenSorted().getEvenAndSort(numArr);
console.log('8) The even & sorted numbers are ('+ getevenSorted +')');