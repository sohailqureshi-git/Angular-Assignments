export class Factorial {
    calculateFactorial(n: number) {
        let factorial = 1;
        while (n >= 1) {
            factorial = factorial * n;
            n--;
        }
        return factorial;
    }
}