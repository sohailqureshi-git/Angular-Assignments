export class PrimeNumber {

    getPrimeNumbers(n: number) {
        let numberArray = [];

        for (var i = 3; i < n; i += 2) {
            if (this.checkPrime(i)) {
                numberArray.push(i);
            }
        }

        return numberArray;
    }


    checkPrime(num) {

        for (var i = 2; i < num; i++) {
            if (num % i === 0) {
                return false;
            }
        }
        return true;
    }


}