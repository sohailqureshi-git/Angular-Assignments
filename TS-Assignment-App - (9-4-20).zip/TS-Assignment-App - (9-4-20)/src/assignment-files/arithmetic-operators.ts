
export class ArithmeticOperation {

    doCalculations(x: number, y: number) {
        let resultArr = [];

        let add = x + y;
        resultArr.push(add);
        let sub = x - y;
        resultArr.push(sub);
        let mul = x * y;
        resultArr.push(mul);
        let div = x / y;
        resultArr.push(div);

        return resultArr;
    }

}