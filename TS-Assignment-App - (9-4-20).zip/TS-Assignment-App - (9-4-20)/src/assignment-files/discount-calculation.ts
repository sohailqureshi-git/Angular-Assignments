export class Discount {
    getDiscount(priceArr: number[]) {
        let resultArr = [];
        for (var i = 0; i < priceArr.length; i++) {
            let result: number = (priceArr[i]/100)*50
            resultArr.push(result.toFixed(2));
        }
        return resultArr;
    }
}