export class Student {

    enrolmentNumber: number;
    studentName: string;

    constructor(number: number, name: string) {
        this.enrolmentNumber = number;
        this.studentName = name;
    }

    showDetails = () => this.enrolmentNumber + ' & ' + this.studentName;
}

