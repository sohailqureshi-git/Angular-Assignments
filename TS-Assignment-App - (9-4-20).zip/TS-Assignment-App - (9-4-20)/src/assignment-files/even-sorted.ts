export class EvenSorted {

    getEvenAndSort(numArr: number[]) {

        let resultArr = [];
        for (var i = 0; i < numArr.length; i++) {
            if (numArr[i] % 2 == 0) {
                resultArr.push(numArr[i]);
            }
        }
        return resultArr.sort((n1,n2) => n1 - n2);
    }
}