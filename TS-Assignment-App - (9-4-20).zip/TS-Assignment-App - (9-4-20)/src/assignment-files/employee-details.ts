class AdhocEmployee {
    workingHours: number;

    constructor(hours: number) {
        this.workingHours = hours;
    }
}

export class Employee extends AdhocEmployee {

    name: string;
    color: string;
    birthYear: number;

    constructor(empName: string, color: string, year: number, hours: number) {
        super(hours);
        this.name = empName;
        this.color = color;
        this.birthYear = year;
    }

    getEmpDetails = () => this.name + ', ' + this.color + ', ' + this.birthYear + ', ' + this.workingHours;

}
