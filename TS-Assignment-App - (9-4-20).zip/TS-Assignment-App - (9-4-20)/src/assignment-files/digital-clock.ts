export class DigitalClock {

    showTime() {
        let time = new Date();
        return time.toLocaleTimeString('en-US');
    }

}